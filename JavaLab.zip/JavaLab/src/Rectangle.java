
public class Rectangle {
	
	    public static void drawRectangle(int x,int y)
		{
			for(int m=0;m<x;m++)
			{
				for(int n=0;n<y;n++)
				{
					System.out.print(" * ");
				}
				System.out.println(); 
			}
			System.out.println();	
		}	
		public static void main(String [] args)
		{
		    drawRectangle(5,8);
		}
	}

